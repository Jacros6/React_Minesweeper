import React, {useState, useEffect} from "react";

//Source https://medium.com/codex/react-stopwatch-10bf9813d0ec
export default function Stopwatch(props) {
    const [time, setTime] = useState(0);
    const [start, setStart] = useState(false)

    useEffect(() => {
        let interval = null;

        if (start) {
            interval = setInterval(() => {
                setTime(prevTime => prevTime + 10)
            }, 1000)
        } else{
            clearInterval(interval);
        }
        return () => clearInterval((interval))
            }, [start])


    return (
        <body>
        <h1 align="center">
            <span>{("0" + (time/10) % 1000)}</span>
        </h1>
            <button onClick={() => setStart(true)}>Start</button>
            <button onClick={() => setStart(false)}>Stop</button>
            <button onClick={() => setTime(0)}>Reset</button>
        </body>
    );
}

