import './App.css';

function App() {
  return (
  <header>Sweeper</header>
  );
}

export default App;
